package dilemaprisionero.src;

import java.util.Random;

class JugadorAlice extends Jugador {

    public JugadorAlice(int id) {
        super(id);
    }
    
    //funcion para decidir aleatoriamente que accion hacer

    @Override
    public Accion decidirAccion() {
     
        Random rand = new Random();
        return rand.nextBoolean() ? Accion.COLABORAR : Accion.ROBAR;
    }
}