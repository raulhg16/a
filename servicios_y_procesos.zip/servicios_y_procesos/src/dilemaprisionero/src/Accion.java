package dilemaprisionero.src;
// Enumeración que representa las acciones posibles de un jugador
enum Accion {
    COLABORAR,
    ROBAR
}
