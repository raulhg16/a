package dilemaprisionero.src;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.util.Scanner;

public class Cliente {
//para que funcione bien tienes que ejecutar primero el servidor y luego ejecutar dos veces el cliente
	
	 private static final String SERVIDOR = "localhost"; 
	    private static final int PUERTO = 12345; 

	    public static void main(String[] args) {
	        try (Socket socket = new Socket(SERVIDOR, PUERTO)) {
	            // Crear streams para la comunicación con el servidor
	            DataInputStream entrada = new DataInputStream(socket.getInputStream());
	            DataOutputStream salida = new DataOutputStream(socket.getOutputStream());
	  

	            // Lee las decisiones del jugador
	            for (int i = 0; i < 10; i++) {
	                System.out.println("Partida " + (i + 1));
	                
	                String accion = decidirAccion(i);

	                // Enviar la acción al servidor
	                salida.writeUTF(accion);
	                System.out.println("Elegiste: " + accion);

	                // Recibir la acción del otro jugador
	                String accionRival = entrada.readUTF();
	                System.out.println("El rival eligió: " + accionRival);

	
	                try {
	                    Thread.sleep(1000);
	                } catch (InterruptedException e) {
	                    e.printStackTrace();
	                }
	            }

	        } catch (IOException e) {
	            e.printStackTrace();
	        }
	    }

	    // Decisión de un jugador
	    private static String decidirAccion(int ronda) {
	     
	        if (ronda % 2 == 0) {
	            return "COLABORAR"; 
	        } else {
	            return "ROBAR"; 
	        }
	    }
}
