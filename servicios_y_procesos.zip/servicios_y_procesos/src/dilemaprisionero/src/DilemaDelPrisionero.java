package dilemaprisionero.src;
public class DilemaDelPrisionero {

    public static void main(String[] args) throws InterruptedException {
    	   int numeroDePartidas = 10; //aqui puedes indicar el numero de rondas que quieres jugar

           // Crear los jugadores
           Jugador colaborador = new JugadorColaborador(1);
           Jugador ratero = new JugadorRatero(2);
           Jugador alice = new JugadorAlice(3);
           Jugador bob = new JugadorBob(4);
           Jugador charlie = new JugadorCharlie(5);

       
           System.out.println("¡Comenzando el juego del Dilema del Prisionero!\n");

           // for para jugar varias partidas
           for (int i = 0; i < numeroDePartidas; i++) {
               System.out.println("\nPartida " + (i + 1) + ":");

               //el profesor puede elegir qué jugadores participarán en cada partida
               Thread jugador1 = new Thread(alice);  
               Thread jugador2 = new Thread(bob);       

               // Crear la partida
               Partida partida = new Partida(jugador1, jugador2);
               partida.jugar();
           }

      
           System.out.println("\nJuego terminado. ¡Gracias por jugar!");
       }
}
