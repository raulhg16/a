package dilemaprisionero.src;

class JugadorBob extends Jugador {
    private boolean esPar = true;

    public JugadorBob(int id) {
        super(id);
    }

    //funcion para que si la partida es impar colabore y si es par decida robar
    @Override
    public Accion decidirAccion() {
      
        if (esPar) {
            esPar = false; 
            return Accion.COLABORAR;
        } else {
            esPar = true; 
            return Accion.ROBAR;
        }
    }
}
