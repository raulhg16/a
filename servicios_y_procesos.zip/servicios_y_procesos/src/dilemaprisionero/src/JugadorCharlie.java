package dilemaprisionero.src;

class JugadorCharlie extends Jugador {
	 private boolean primeraPartida = true;
	    private Accion ultimaAccionRival = setUltimaAccionRival(accion);

	    public JugadorCharlie(int id) {
	        super(id);
	    }

	    //funcion para que la primera partida colabore y luego imite al rival
	    @Override
	    public Accion decidirAccion() {
	        if (primeraPartida) {
	            primeraPartida = false;
	            return Accion.COLABORAR; 
	        } else {
	            return ultimaAccionRival; 
	        }
	    }

	    // funcion para que charlie reciba la acción del rival y la imite en la siguiente ronda
	    public Accion setUltimaAccionRival(Accion accionRival) {
	        ultimaAccionRival = accionRival;
	        
	        return accionRival;
	    }
	}
