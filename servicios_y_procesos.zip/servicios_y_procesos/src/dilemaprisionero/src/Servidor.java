package dilemaprisionero.src;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

public class Servidor {
	private static final int PUERTO = 12345; 

    public static void main(String[] args) throws IOException {
        // Iniciar el servidor y esperar conexiones
        ServerSocket servidor = new ServerSocket(PUERTO);
        System.out.println("Esperando jugadores...");
        
        // Aceptar dos conexiones de clientes
        Socket jugador1Socket = servidor.accept();
        Socket jugador2Socket = servidor.accept();

        System.out.println("Jugador 1 y Jugador 2 conectados");

        // Crear streams para la comunicación con los jugadores
        DataInputStream entrada1 = new DataInputStream(jugador1Socket.getInputStream());
        DataOutputStream salida1 = new DataOutputStream(jugador1Socket.getOutputStream());

        DataInputStream entrada2 = new DataInputStream(jugador2Socket.getInputStream());
        DataOutputStream salida2 = new DataOutputStream(jugador2Socket.getOutputStream());

        // Iniciar el juego
        for (int i = 0; i < 10; i++) {
            System.out.println("Partida " + (i + 1));

            // Recibir las decisiones de ambos jugadores
            String accionJugador1 = entrada1.readUTF();
            String accionJugador2 = entrada2.readUTF();

            System.out.println("Jugador 1 eligió: " + accionJugador1);
            System.out.println("Jugador 2 eligió: " + accionJugador2);

            // Enviar las decisiones de vuelta al otro jugador
            salida1.writeUTF(accionJugador2); 
            salida2.writeUTF(accionJugador1); 

            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }

        // Cerrar las conexiones
        jugador1Socket.close();
        jugador2Socket.close();
        servidor.close();
    }

}
